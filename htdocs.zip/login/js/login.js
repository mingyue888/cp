//$("#title-button").find("p").click(function(e){
//    var index=$(e.target).index();
//    //按钮样式切换
//    $(this).find("div").addClass("toggle-bottom-border").parent().siblings().find("div").removeClass("toggle-bottom-border");
//    //按钮显示隐藏实现
//    //$("#title-button").find("section").eq(index).show().siblings().hide();
//});
//改宽
$("#title-button").find("p").click(function(e){
    var index=$(e.target).index();
    //获取字宽
    $()
    //改宽度
    $(e.target).css("width",)
});
